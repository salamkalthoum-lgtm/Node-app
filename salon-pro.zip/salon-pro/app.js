const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const session = require('express-session');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const multer = require('multer');
const QRCode = require('qrcode');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine','ejs');
app.use(expressLayouts);
app.set('layout', path.join(__dirname,'views','partials','layout'));

app.use('/public', express.static(path.join(__dirname,'public')));
app.use(bodyParser.urlencoded({ extended:true }));
app.use(bodyParser.json());
app.use(session({ secret:'salon-secret', resave:false, saveUninitialized:false }));

const upload = multer({ dest: path.join(__dirname,'public','uploads') });

function requireAdmin(req,res,next){
  if (req.session && req.session.user) return next();
  res.redirect('/admin/login');
}

// Home
app.get('/', (req,res)=>{
  db.all('SELECT * FROM Services ORDER BY category,price', (err, services)=>{
    db.all('SELECT * FROM Staff ORDER BY id', (err2, staff)=>{
      res.render('index',{ page:'home', services, staff });
    });
  });
});

// Sections
app.get('/hair', (req,res)=>{
  db.all("SELECT * FROM Gallery WHERE category='Hair' ORDER BY id DESC", (err, images)=>{
    db.all("SELECT * FROM Staff WHERE specialty='Hair'", (err2, staff)=>{
      res.render('hair',{ page:'hair', images, staff });
    });
  });
});
app.get('/makeup', (req,res)=>{
  db.all("SELECT * FROM Gallery WHERE category='Makeup' ORDER BY id DESC", (err, images)=>{
    db.all("SELECT * FROM Staff WHERE specialty='Makeup'", (err2, staff)=>{
      res.render('makeup',{ page:'makeup', images, staff });
    });
  });
});

// Booking page
app.get('/booking', (req,res)=>{
  res.render('booking',{ page:'booking' });
});

app.post('/booking', (req,res)=>{
  const { fullName, peopleCount, date, time, phone, notes } = req.body;
  const pc = parseInt(peopleCount||'1',10);
  const services = [];
  for (let i=1;i<=pc;i++){
    services.push(req.body[`service_person_${i}`] || '');
  }
  const servicesText = JSON.stringify(services);
  const createdAt = new Date().toISOString();
  db.run('INSERT INTO Bookings (fullName,peopleCount,servicesText,date,time,phone,notes,createdAt) VALUES (?,?,?,?,?,?,?,?,?)',
    [fullName,pc,servicesText,date,time,phone,notes||'',createdAt],
    function(err){
      if (err) return res.status(500).send('DB error');
      const bookingId = this.lastID;
      const payload = `حجز#${bookingId}|${fullName}|${date}|${time}`;
      const qrPath = path.join(__dirname,'public','qrcodes',`booking_${bookingId}.png`);
      QRCode.toFile(qrPath, payload, { errorCorrectionLevel:'H' }, (e)=>{
        if (e) {
          console.error('QR error', e);
          return res.render('success',{ page:'booking', bookingId, qrDataUrl:null });
        }
        const qrUrl = `/public/qrcodes/booking_${bookingId}.png`;
        # store path in DB
        db.run('UPDATE Bookings SET qrCode=? WHERE id=?', [qrUrl, bookingId], ()=>{
          res.render('success',{ page:'booking', bookingId, qrDataUrl: qrUrl });
        });
      });
    });
});

// Admin auth
app.get('/admin/login',(req,res)=> res.render('admin-login',{ page:'admin' }));
app.post('/admin/login',(req,res)=>{
  const { username, password } = req.body;
  db.get('SELECT * FROM Admins WHERE username=? AND password=?', [username, password], (err,row)=>{
    if (row){ req.session.user = { id: row.id, username: row.username }; return res.redirect('/admin'); }
    res.render('admin-login',{ page:'admin', error:'بيانات خاطئة' });
  });
});
app.get('/admin/logout',(req,res)=>{ req.session.destroy(()=>res.redirect('/admin/login')); });

# Admin dashboard
app.get('/admin', requireAdmin, (req,res)=>{
  const { date_from, date_to, status, phone } = req.query;
  const params=[]; let where='WHERE 1=1';
  if (date_from){ where += ' AND date >= ?'; params.push(date_from); }
  if (date_to){ where += ' AND date <= ?'; params.push(date_to); }
  if (status && status!=='all'){ where += ' AND status = ?'; params.push(status); }
  if (phone){ where += ' AND phone LIKE ?'; params.push('%'+phone+'%'); }
  db.all(`SELECT * FROM Bookings ${where} ORDER BY date DESC, time DESC`, params, (err, bookings)=>{
    db.all('SELECT * FROM Services ORDER BY category,price', (err2, services)=>{
      db.all('SELECT * FROM Staff ORDER BY id', (err3, staff)=>{
        res.render('admin',{ page:'admin', bookings, services, staff, filters:{date_from, date_to, status: status||'all', phone} });
      });
    });
  });
});

// Update status (no QR generation here since QR generated at booking)
app.post('/admin/status/:id', requireAdmin, (req,res)=>{
  const { id } = req.params;
  const { status } = req.body;
  db.run('UPDATE Bookings SET status=? WHERE id=?', [status, id], ()=> res.redirect('back'));
});

// Services management
app.post('/admin/services/add', requireAdmin, (req,res)=>{
  const { category, name, price, description } = req.body;
  db.run('INSERT INTO Services (category,name,price,description) VALUES (?,?,?,?)', [category,name,price||0,description||''], ()=>res.redirect('/admin'));
});
app.post('/admin/services/delete/:id', requireAdmin, (req,res)=>{ db.run('DELETE FROM Services WHERE id=?', [req.params.id], ()=>res.redirect('back')); });

# Staff management (names only)
app.post('/admin/staff/add', requireAdmin, (req,res)=>{
  const { name, specialty } = req.body;
  db.run('INSERT INTO Staff (name,specialty) VALUES (?,?)', [name,specialty||''], ()=>res.redirect('back'));
});
app.post('/admin/staff/delete/:id', requireAdmin, (req,res)=>{ db.run('DELETE FROM Staff WHERE id=?', [req.params.id], ()=>res.redirect('back')); });

# Gallery upload (admin)
const gupload = multer({ dest: path.join(__dirname,'public','uploads') });
app.post('/admin/gallery/add', gupload.single('image'), requireAdmin, (req,res)=>{
  if (!req.file) return res.redirect('back');
  const cat = req.body.category === 'Makeup' ? 'makeup' : 'hair';
  const dest = path.join(__dirname,'public','images',cat);
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive:true });
  const newName = Date.now() + '_' + req.file.originalname;
  fs.renameSync(req.file.path, path.join(dest, newName));
  const imagePath = `/public/images/${cat}/${newName}`;
  db.run('INSERT INTO Gallery (category,image,staffId,caption) VALUES (?,?,?,?)', [req.body.category, imagePath, req.body.staffId||null, req.body.caption||''], ()=>res.redirect('back'));
});
app.post('/admin/gallery/delete/:id', requireAdmin, (req,res)=>{
  db.get('SELECT image FROM Gallery WHERE id=?', [req.params.id], (err,row)=>{
    if (row && row.image){ const p = path.join(__dirname, row.image.replace('/public/','public/')); fs.unlink(p, ()=>{}); }
    db.run('DELETE FROM Gallery WHERE id=?', [req.params.id], ()=>res.redirect('back'));
  });
});

app.listen(PORT, ()=> console.log(`Salon pro running on http://localhost:${PORT}`));
