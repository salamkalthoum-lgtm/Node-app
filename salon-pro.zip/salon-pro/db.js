const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, 'salon.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS Services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    description TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS Staff (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    specialty TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS Gallery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    image TEXT NOT NULL,
    staffId INTEGER,
    caption TEXT,
    FOREIGN KEY(staffId) REFERENCES Staff(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS Bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fullName TEXT NOT NULL,
    peopleCount INTEGER NOT NULL,
    servicesText TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    phone TEXT NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'بانتظار',
    qrCode TEXT,
    createdAt TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS Admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
  )`);

  // seed
  db.get('SELECT COUNT(*) as cnt FROM Services', (err,row)=>{
    if (row && row.cnt===0){
      const s=[
        ['Hair','قص شعر','20','قص شعر عادي'],
        ['Hair','فير','15','تسريح فير'],
        ['Hair','صبغة كاملة','50','صبغة كاملة'],
        ['Makeup','مكياج خفيف','30','مظهر طبيعي'],
        ['Makeup','مكياج كامل','80','مكياج سهرات']
      ];
      const st = db.prepare('INSERT INTO Services (category,name,price,description) VALUES (?,?,?,?)');
      s.forEach(x=>st.run(x));
      st.finalize();
    }
  });

  db.get('SELECT COUNT(*) as cnt FROM Staff', (err,row)=>{
    if (row && row.cnt===0){
      const st = db.prepare('INSERT INTO Staff (name,specialty) VALUES (?,?)');
      st.run('سارة','Hair');
      st.run('منى','Makeup');
      st.run('ليلى','Hair');
      st.finalize();
    }
  });

  db.get('SELECT COUNT(*) as cnt FROM Admins', (err,row)=>{
    if (row && row.cnt===0){
      db.run('INSERT INTO Admins (username,password) VALUES (?,?)', ['admin','admin123']);
    }
  });
});

module.exports = db;
